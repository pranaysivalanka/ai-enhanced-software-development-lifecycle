import requests

API_BASE = "http://localhost:8000"

def classify_pdf(file):
    return requests.post(f"{API_BASE}/api/upload-pdf", files={"file": file}).json()

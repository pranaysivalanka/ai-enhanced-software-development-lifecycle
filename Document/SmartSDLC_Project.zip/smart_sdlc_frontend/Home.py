import streamlit as st
from api_client import classify_pdf

st.title("SmartSDLC 🧠")
pdf = st.file_uploader("Upload your requirement document")

if pdf and st.button("Classify"):
    result = classify_pdf(pdf)
    st.json(result)

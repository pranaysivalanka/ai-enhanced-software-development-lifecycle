from fastapi import FastAPI
from app.routes import ai_routes

app = FastAPI(title="SmartSDLC API")

app.include_router(ai_routes.router, prefix="/api")

@app.get("/")
def root():
    return {"message": "SmartSDLC Backend Running"}

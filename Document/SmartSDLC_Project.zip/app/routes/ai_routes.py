from fastapi import APIRouter, UploadFile, File
from app.services.requirement_service import classify_requirements

router = APIRouter()

@router.post("/upload-pdf")
async def upload_pdf(file: UploadFile = File(...)):
    content = await file.read()
    results = classify_requirements(content)
    return {"classified": results}
